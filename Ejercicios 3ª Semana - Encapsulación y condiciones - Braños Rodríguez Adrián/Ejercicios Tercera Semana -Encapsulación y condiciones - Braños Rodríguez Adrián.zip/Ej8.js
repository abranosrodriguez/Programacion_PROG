var texto = prompt("Escribeme algo: ")

if (texto.length%2 == 0) {
    alert("La cadena de texto es par")
}else{
    alert("La cadena de texto es impar")
}
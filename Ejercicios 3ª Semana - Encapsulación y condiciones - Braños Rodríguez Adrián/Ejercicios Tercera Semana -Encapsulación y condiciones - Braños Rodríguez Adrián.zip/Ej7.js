var numero = prompt("Dame un número entero: ")

if (numero%2 == 0) {
    alert("El número es par")
}else{
    alert("El número es impar")
}
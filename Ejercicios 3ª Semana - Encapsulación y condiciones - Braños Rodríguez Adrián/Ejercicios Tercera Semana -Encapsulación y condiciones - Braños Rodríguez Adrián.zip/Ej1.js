var num_intro_usu = prompt("Dame un número: ")
if (num_intro_usu < 10) {
    alert("El numero es menor que 10")
}
if (num_intro_usu > 10){
    alert("El número es mayor que 10")
}
if (num_intro_usu == 10){
    alert("Los números son iguales")
}
var palabra = prompt("Dame unas palabras: ")
const letra = "b"


if (palabra.includes("b") == true) {
    alert("La palabra/s tiene b")
}

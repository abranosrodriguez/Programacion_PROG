var nombre = prompt("Introduce un nombre de usuario: ")
var localidad = prompt("¿Donde vives? ")
var gusto = prompt("Dime un gusto tuyo: ")

alert("Hola :D; mi nombre es" + " " + nombre + " " + ",mis gustos son los " + gusto + " " + "y soy de " + localidad)
var dato1 = prompt("Dame un primer valor: ")
var dato2 = prompt("Dame un segundo valor: ")

if (dato1==dato2) {
    alert("Los valores son iguales")
}else{
    alert("Los valores son distintos")
}

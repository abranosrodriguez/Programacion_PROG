var numero1 = prompt("Dame el primer valor: ")
var numero2 = prompt("Dame el segundo valor: ")

var numero3 = (numero1 * numero1) + (numero2 * numero2)
var raiz = Math.sqrt(numero3)

alert("El resultado del módulo es: " + raiz)

/* 
    x = (n1,n2) -> numero 1 y 2 
    x = (n1*n1)+(n2*n2)=n1+n2=n3
    x= raiz cuadrada de n3 
*/ 
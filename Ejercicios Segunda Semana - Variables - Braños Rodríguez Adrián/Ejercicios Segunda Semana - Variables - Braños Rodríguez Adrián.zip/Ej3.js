var nombre = "Adrian Branhos"
var localidad = "Redondela"
var gusto = "videojuegos"

alert("Hola :D; mi nombre es" + " " + nombre + " " + ",me gustan los " + gusto + " " + "y soy de " + " " + localidad)
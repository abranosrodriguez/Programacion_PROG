var texto1 = prompt("Dame un valor: ")
var texto2 = prompt("Dame un segundo valor: ")

if (texto1 === texto2) {
    alert("Los valores son completamente iguales")
}else{
    alert("Los valores son completamente distintos")
}
var numero = prompt("Dame un número: ")
var numero1 = numero * 1
var numero2 = numero * 2
var numero3 = numero * 3
var numero4 = numero * 4
var numero5 = numero * 5
var numero6 = numero * 6
var numero7 = numero * 7
var numero8 = numero * 8
var numero9 = numero * 9

alert("1 x"+ numero +"=" +numero1 + "," + "2 x"+ numero +"=" +numero2 + "," + "3 x"+ numero +"=" +numero3 + "," + "4 x"+ numero +"=" +numero4 + "," +
"5 x"+ numero +"=" +numero5 + "," + "6 x"+ numero +"=" +numero6 + "," + "7 x"+ numero +"=" +numero7 + "," + "8 x"+ numero +"=" +numero8 + "," + "9 x"+ numero +"=" +numero9) 
// numero * 1 / numero * 2 .. numero * 9
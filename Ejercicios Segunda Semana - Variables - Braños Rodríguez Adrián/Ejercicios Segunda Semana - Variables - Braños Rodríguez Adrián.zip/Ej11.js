var valor1 = prompt("Dame el primer valor: ")
var valor2 = prompt("Dame el segundo valor: ")
var valor3 = prompt("Dame el tercer valor: ")

if (valor1 == valor2){
    alert("El valor 1 es igual al valor 2") 
}
if (valor1 == valor3) {
    alert("El valor 1 es igual al valor 3") 
}
if (valor2 == valor3) {
    alert("El valor 2 es igual al valor 3") 
}
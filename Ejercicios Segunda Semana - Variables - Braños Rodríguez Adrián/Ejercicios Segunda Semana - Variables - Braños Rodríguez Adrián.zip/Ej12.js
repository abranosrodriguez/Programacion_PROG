
var dato1 = prompt("Dame un número que quieras: " )
dato1++
var dato2 = prompt("Dame un segundo número que quieras ")
var dato3 = dato1 * dato2

alert("El resultado es: " + dato3)
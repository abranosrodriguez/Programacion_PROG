var base=5
var altura=7

var area= base * altura

alert("El resultado es:" + " " + area)
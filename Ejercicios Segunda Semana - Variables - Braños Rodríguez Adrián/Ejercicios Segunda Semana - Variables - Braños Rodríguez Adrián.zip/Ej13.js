var edad = prompt("Cuantos años tienes?")
var resultado= 2021 - edad
 alert("Naciste en el año: " + resultado)
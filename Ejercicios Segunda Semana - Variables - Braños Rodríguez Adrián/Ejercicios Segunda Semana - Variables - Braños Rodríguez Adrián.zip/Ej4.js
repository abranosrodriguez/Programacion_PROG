var altura = prompt("Introduce una altura: ")
var base = prompt ("Introduce una base: ")

var area = altura * base

alert("El area es " + area)
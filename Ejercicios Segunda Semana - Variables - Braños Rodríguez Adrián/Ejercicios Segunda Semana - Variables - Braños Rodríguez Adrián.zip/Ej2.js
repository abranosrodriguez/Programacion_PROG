var pi = 3.14
var radio = 7

var area = pi * (radio*radio)
var longitud = 2 * pi * radio

alert("El area de la circunferencia es:" + " " + area )
alert("La longitud de la circunferencia es:" + " " + longitud)

//Longitud = 2 x 3,14 x 7
//Area= 3,14 x (7x7)
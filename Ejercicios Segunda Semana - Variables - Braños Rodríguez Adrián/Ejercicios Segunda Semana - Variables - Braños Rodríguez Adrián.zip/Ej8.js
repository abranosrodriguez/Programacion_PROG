// Dando un valor x se eleve dicho valor, 2^x
var numero = 2
var elevado = prompt("Dame un número: ")
var resultado = Math.pow(numero, elevado)

alert("El resultado es:" + " " + resultado)
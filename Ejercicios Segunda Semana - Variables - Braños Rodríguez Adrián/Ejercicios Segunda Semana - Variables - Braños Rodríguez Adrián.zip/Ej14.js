var dato = prompt("¿Cuántos años tienes? ")

if (dato < (18)) {
    alert("Eres menos, no puedes tener el carnet de conducir")
}else{
    alert("Puedes tener el carnet de conducir")
}